package com.elitemaster.booster;

import android.app.Activity;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.ContentValues;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.hardware.display.DisplayManager;
import android.hardware.display.VirtualDisplay;
import android.media.MediaRecorder;
import android.media.projection.MediaProjection;
import android.media.projection.MediaProjectionManager;
import android.net.Uri;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.ParcelFileDescriptor;
import android.provider.MediaStore;
import android.util.DisplayMetrics;
import android.view.WindowManager;
import android.widget.Toast;

/** Screen recorder: up to 1080p, 60 fps target, 16 Mbps H.264. Optional microphone (voice) track. */
public class RecordService extends Service {
    public static final String ACTION_START = "com.elitemaster.booster.START";
    public static final String ACTION_STOP = "com.elitemaster.booster.STOP";
    public static boolean running = false;
    public static Runnable listener;
    private static final String CH = "elite_rec";

    private MediaProjection projection;
    private VirtualDisplay display;
    private MediaRecorder recorder;
    private ParcelFileDescriptor pfd;
    private Uri uri;
    private boolean started, stopping;

    @Override public int onStartCommand(Intent in, int flags, int id) {
        if (in == null) { stopSelf(); return START_NOT_STICKY; }
        if (ACTION_STOP.equals(in.getAction())) { finish(); return START_NOT_STICKY; }

        boolean voice = in.getBooleanExtra("voice", false);
        getSystemService(NotificationManager.class)
            .createNotificationChannel(new NotificationChannel(CH, "Recorder", NotificationManager.IMPORTANCE_LOW));
        Intent stop = new Intent(this, RecordService.class).setAction(ACTION_STOP);
        PendingIntent pi = PendingIntent.getService(this, 0, stop, PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
        Notification n = new Notification.Builder(this, CH).setSmallIcon(android.R.drawable.presence_video_online)
            .setContentTitle("ELITE MASTER").setContentText(voice ? "Recording screen + voice" : "Recording screen")
            .setOngoing(true)
            .addAction(new Notification.Action.Builder(null, "STOP", pi).build()).build();
        int type = ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION;
        if (voice) type |= ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE;
        startForeground(3001, n, type);

        try {
            Intent data = getData(in);
            if (data == null) throw new IllegalStateException("no permission data");
            begin(in.getIntExtra("resultCode", Activity.RESULT_CANCELED), data, voice);
        } catch (Exception e) {
            android.util.Log.e("EliteRec", "start failed", e);
            Toast.makeText(this, "Recording failed to start", Toast.LENGTH_SHORT).show();
            finish();
        }
        return START_NOT_STICKY;
    }

    private void begin(int code, Intent data, boolean voice) throws Exception {
        MediaProjectionManager m = (MediaProjectionManager) getSystemService(MEDIA_PROJECTION_SERVICE);
        projection = m.getMediaProjection(code, data);
        if (projection == null) throw new IllegalStateException("projection null");
        projection.registerCallback(new MediaProjection.Callback() {
            @Override public void onStop() { finish(); }
        }, new Handler(Looper.getMainLooper()));

        DisplayMetrics dm = new DisplayMetrics();
        ((WindowManager) getSystemService(WINDOW_SERVICE)).getDefaultDisplay().getRealMetrics(dm);
        float sc;
        // fit inside 1920x1080 (landscape) or 1080x1920 (portrait), keep aspect ratio
        int longSide = Math.max(dm.widthPixels, dm.heightPixels), shortSide = Math.min(dm.widthPixels, dm.heightPixels);
        sc = Math.min(1f, Math.min(1920f / longSide, 1080f / shortSide));
        int w = Math.max(2, ((int) (dm.widthPixels * sc)) & ~1);
        int hh = Math.max(2, ((int) (dm.heightPixels * sc)) & ~1);

        ContentValues cv = new ContentValues();
        cv.put(MediaStore.Video.Media.DISPLAY_NAME, "ELITE_MASTER_" + System.currentTimeMillis() + ".mp4");
        cv.put(MediaStore.Video.Media.MIME_TYPE, "video/mp4");
        cv.put(MediaStore.Video.Media.RELATIVE_PATH, "Movies/ELITE MASTER");
        cv.put(MediaStore.Video.Media.IS_PENDING, 1);
        uri = getContentResolver().insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, cv);
        if (uri == null) throw new IllegalStateException("insert failed");
        pfd = getContentResolver().openFileDescriptor(uri, "w");

        recorder = new MediaRecorder();
        if (voice) recorder.setAudioSource(MediaRecorder.AudioSource.MIC);
        recorder.setVideoSource(MediaRecorder.VideoSource.SURFACE);
        recorder.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4);
        if (voice) {
            recorder.setAudioEncoder(MediaRecorder.AudioEncoder.AAC);
            recorder.setAudioSamplingRate(48000);
            recorder.setAudioEncodingBitRate(192000);
        }
        recorder.setVideoEncoder(MediaRecorder.VideoEncoder.H264);
        recorder.setVideoSize(w, hh);
        recorder.setVideoFrameRate(60);
        recorder.setVideoEncodingBitRate(16_000_000);
        recorder.setOutputFile(pfd.getFileDescriptor());
        recorder.prepare();

        display = projection.createVirtualDisplay("EliteRec", w, hh, dm.densityDpi,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, recorder.getSurface(), null, null);
        recorder.start();
        started = true;
        running = true;
        if (listener != null) listener.run();
    }

    private void finish() {
        if (stopping) return;
        stopping = true;
        boolean ok = false;
        if (display != null) { display.release(); display = null; }
        if (recorder != null) {
            if (started) { try { recorder.stop(); ok = true; } catch (RuntimeException e) { android.util.Log.w("EliteRec", "too short", e); } }
            try { recorder.reset(); } catch (Exception ignored) {}
            recorder.release(); recorder = null;
        }
        if (projection != null) { try { projection.stop(); } catch (Exception ignored) {} projection = null; }
        if (pfd != null) { try { pfd.close(); } catch (Exception ignored) {} pfd = null; }
        if (uri != null) {
            if (ok) {
                ContentValues d = new ContentValues(); d.put(MediaStore.Video.Media.IS_PENDING, 0);
                getContentResolver().update(uri, d, null, null);
                Toast.makeText(this, "Saved to Movies/ELITE MASTER", Toast.LENGTH_SHORT).show();
            } else {
                getContentResolver().delete(uri, null, null);
            }
            uri = null;
        }
        started = false; running = false;
        if (listener != null) listener.run();
        stopForeground(true);
        stopSelf();
    }

    @Override public void onDestroy() { if (!stopping) finish(); super.onDestroy(); }
    @SuppressWarnings("deprecation")
    private static Intent getData(Intent i) {
        if (i == null) return null;
        return android.os.Build.VERSION.SDK_INT >= 33 ? i.getParcelableExtra("resultData", Intent.class) : (Intent) i.getParcelableExtra("resultData");
    }

    @Override public IBinder onBind(Intent i) { return null; }
}
