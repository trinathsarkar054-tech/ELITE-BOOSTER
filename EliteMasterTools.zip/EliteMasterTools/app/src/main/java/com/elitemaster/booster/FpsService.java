package com.elitemaster.booster;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.os.IBinder;
import android.view.Choreographer;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.WindowManager;
import android.widget.TextView;

/** Live frame-rate overlay driven by Choreographer (real, per-second measurement). */
public class FpsService extends Service implements Choreographer.FrameCallback {
    public static boolean running = false;
    public static Runnable listener;
    private static final String CH = "elite_fps";
    private WindowManager wm;
    private TextView view;
    private WindowManager.LayoutParams lp;
    private long windowStart = 0;
    private int frames = 0;

    @Override public void onCreate() {
        super.onCreate();
        NotificationManager nm = getSystemService(NotificationManager.class);
        nm.createNotificationChannel(new NotificationChannel(CH, "FPS overlay", NotificationManager.IMPORTANCE_LOW));
        Notification n = new Notification.Builder(this, CH)
            .setSmallIcon(android.R.drawable.ic_menu_view)
            .setContentTitle("ELITE MASTER").setContentText("FPS overlay is on").setOngoing(true).build();
        if (Build.VERSION.SDK_INT >= 34) startForeground(4001, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE);
        else startForeground(4001, n);

        wm = (WindowManager) getSystemService(WINDOW_SERVICE);
        view = new TextView(this);
        view.setText("-- FPS");
        view.setTextColor(Color.rgb(80, 255, 120));
        view.setTextSize(15);
        view.setTypeface(android.graphics.Typeface.MONOSPACE, android.graphics.Typeface.BOLD);
        view.setPadding(22, 10, 22, 10);
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(Color.argb(190, 20, 0, 4));
        bg.setStroke(2, Color.rgb(255, 30, 50));
        bg.setCornerRadius(14);
        view.setBackground(bg);

        lp = new WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL
                | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT);
        lp.gravity = Gravity.TOP | Gravity.START;
        lp.x = 40; lp.y = 120;
        view.setOnTouchListener(new android.view.View.OnTouchListener() {
            int sx, sy; float tx, ty;
            @Override public boolean onTouch(android.view.View v, MotionEvent e) {
                switch (e.getAction()) {
                    case MotionEvent.ACTION_DOWN: sx = lp.x; sy = lp.y; tx = e.getRawX(); ty = e.getRawY(); return true;
                    case MotionEvent.ACTION_MOVE:
                        lp.x = sx + (int) (e.getRawX() - tx); lp.y = sy + (int) (e.getRawY() - ty);
                        wm.updateViewLayout(view, lp); return true;
                }
                return false;
            }
        });
        try { wm.addView(view, lp); } catch (Exception e) { stopSelf(); return; }
        running = true;
        notifyState();
        Choreographer.getInstance().postFrameCallback(this);
    }

    @Override public void doFrame(long frameTimeNanos) {
        if (view == null) return;
        if (windowStart == 0) windowStart = frameTimeNanos;
        frames++;
        long dt = frameTimeNanos - windowStart;
        if (dt >= 500_000_000L) {
            int fps = Math.round(frames * 1_000_000_000f / dt);
            view.setText(fps + " FPS");
            view.setTextColor(fps >= 55 ? Color.rgb(80, 255, 120) : fps >= 30 ? Color.rgb(255, 210, 60) : Color.rgb(255, 60, 70));
            frames = 0; windowStart = frameTimeNanos;
        }
        Choreographer.getInstance().postFrameCallback(this);
    }

    private static void notifyState() { if (listener != null) listener.run(); }

    @Override public int onStartCommand(Intent i, int f, int s) { return START_NOT_STICKY; }

    @Override public void onDestroy() {
        running = false;
        Choreographer.getInstance().removeFrameCallback(this);
        if (wm != null && view != null && view.isAttachedToWindow()) wm.removeView(view);
        view = null;
        notifyState();
        super.onDestroy();
    }

    @Override public IBinder onBind(Intent i) { return null; }
}
