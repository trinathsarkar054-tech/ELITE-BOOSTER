package com.elitemaster.booster;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.PopupMenu;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {
    private static final int RED = Color.rgb(255, 26, 46), DARK = Color.rgb(12, 2, 6), PANEL = Color.rgb(26, 5, 10);
    private TextView fpsBtn, recBtn, recMode;
    private int recVoice = 0;          // 0 = device record, 1 = voice record
    private int pendingVoice = -1;

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        if (Build.VERSION.SDK_INT >= 33)
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 1);

        ScrollView sv = new ScrollView(this);
        sv.setBackgroundColor(DARK);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(18), dp(28), dp(18), dp(24));
        sv.addView(root);

        // header: logo + title
        LinearLayout head = new LinearLayout(this);
        head.setGravity(Gravity.CENTER_VERTICAL);
        ImageView logo = new ImageView(this);
        logo.setImageResource(R.drawable.logo);
        head.addView(logo, new LinearLayout.LayoutParams(dp(64), dp(64)));
        LinearLayout titles = new LinearLayout(this);
        titles.setOrientation(LinearLayout.VERTICAL);
        titles.setPadding(dp(14), 0, 0, 0);
        titles.addView(label("ELITE MASTER", 22, Color.WHITE, true));
        titles.addView(label("GAME PANEL", 12, RED, true));
        head.addView(titles);
        root.addView(head);
        root.addView(space(18));

        // buttons
        fpsBtn = button("SHOW FPS");
        fpsBtn.setOnClickListener(v -> toggleFps());
        root.addView(fpsBtn, lp());
        root.addView(space(12));

        LinearLayout recRow = new LinearLayout(this);
        recRow.setGravity(Gravity.CENTER_VERTICAL);
        recBtn = button("SCREEN RECORD");
        recBtn.setOnClickListener(v -> toggleRecord());
        recRow.addView(recBtn, new LinearLayout.LayoutParams(0, dp(58), 1f));
        recMode = button("⋮");                // three dots
        recMode.setTextSize(24);
        recMode.setOnClickListener(this::pickMode);
        LinearLayout.LayoutParams ml = new LinearLayout.LayoutParams(dp(58), dp(58));
        ml.leftMargin = dp(10);
        recRow.addView(recMode, ml);
        root.addView(recRow, new LinearLayout.LayoutParams(-1, -2));
        root.addView(space(6));
        root.addView(label("Mode: tap ⋮ to choose Device record or Voice record", 11, Color.rgb(160, 120, 125), false));
        root.addView(space(12));

        TextView shot = button("SCREENSHOT");
        shot.setOnClickListener(v -> startCapture(CaptureActivity.MODE_SHOT));
        root.addView(shot, lp());
        root.addView(space(18));
        root.addView(label("Recordings: Movies/ELITE MASTER\nScreenshots: Pictures/ELITE MASTER", 11, Color.rgb(160, 120, 125), false));
        setContentView(sv);

        Runnable r = this::refresh;
        FpsService.listener = () -> runOnUiThread(r);
        RecordService.listener = () -> runOnUiThread(r);
    }

    @Override protected void onResume() { super.onResume(); refresh(); fpsBtn.postDelayed(this::refresh, 1200); }

    private void refresh() {
        fpsBtn.setText(FpsService.running ? "HIDE FPS" : "SHOW FPS");
        fpsBtn.setBackground(bg(FpsService.running));
        recBtn.setText(RecordService.running ? "STOP RECORDING" : (recVoice == 1 ? "SCREEN RECORD · VOICE" : "SCREEN RECORD · DEVICE"));
        recBtn.setBackground(bg(RecordService.running));
    }

    private void toggleFps() {
        if (FpsService.running) { stopService(new Intent(this, FpsService.class)); return; }
        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "Allow \"Display over other apps\", then tap SHOW FPS again", Toast.LENGTH_LONG).show();
            startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + getPackageName())));
            return;
        }
        startForegroundService(new Intent(this, FpsService.class));
    }

    private void pickMode(View anchor) {
        PopupMenu m = new PopupMenu(this, anchor);
        m.getMenu().add(0, 0, 0, "Device record (screen only)");
        m.getMenu().add(0, 1, 1, "Voice record (screen + mic)");
        m.setOnMenuItemClickListener(i -> { recVoice = i.getItemId(); refresh(); return true; });
        m.show();
    }

    private void toggleRecord() {
        if (RecordService.running) {
            startService(new Intent(this, RecordService.class).setAction(RecordService.ACTION_STOP));
            return;
        }
        if (recVoice == 1 && checkSelfPermission(Manifest.permission.RECORD_AUDIO) != android.content.pm.PackageManager.PERMISSION_GRANTED) {
            pendingVoice = 1;
            requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, 2);
            return;
        }
        startCapture(recVoice == 1 ? CaptureActivity.MODE_REC_VOICE : CaptureActivity.MODE_REC_DEVICE);
    }

    @Override public void onRequestPermissionsResult(int code, String[] p, int[] r) {
        if (code == 2 && pendingVoice == 1) {
            pendingVoice = -1;
            if (r.length > 0 && r[0] == android.content.pm.PackageManager.PERMISSION_GRANTED)
                startCapture(CaptureActivity.MODE_REC_VOICE);
            else Toast.makeText(this, "Microphone permission needed for Voice record", Toast.LENGTH_LONG).show();
        }
    }

    private void startCapture(int mode) {
        startActivity(new Intent(this, CaptureActivity.class).putExtra(CaptureActivity.EXTRA_MODE, mode));
    }

    // ---- small UI helpers ----
    private int dp(int v) { return (int) (v * getResources().getDisplayMetrics().density); }
    private View space(int h) { View v = new View(this); v.setLayoutParams(new LinearLayout.LayoutParams(1, dp(h))); return v; }
    private LinearLayout.LayoutParams lp() { return new LinearLayout.LayoutParams(-1, dp(58)); }
    private TextView label(String t, int sp, int c, boolean bold) {
        TextView v = new TextView(this); v.setText(t); v.setTextSize(sp); v.setTextColor(c);
        v.setTypeface(Typeface.DEFAULT, bold ? Typeface.BOLD : Typeface.NORMAL); v.setLetterSpacing(bold ? 0.08f : 0f); return v;
    }
    private TextView button(String t) {
        TextView v = new TextView(this); v.setText(t); v.setTextSize(15); v.setTextColor(Color.WHITE);
        v.setTypeface(Typeface.DEFAULT, Typeface.BOLD); v.setLetterSpacing(0.1f); v.setGravity(Gravity.CENTER);
        v.setBackground(bg(false)); v.setClickable(true); return v;
    }
    private GradientDrawable bg(boolean active) {
        GradientDrawable g = new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM,
            active ? new int[]{Color.rgb(255, 60, 80), Color.rgb(160, 0, 20)} : new int[]{Color.rgb(52, 10, 18), PANEL});
        g.setCornerRadius(dp(14)); g.setStroke(dp(1), RED); return g;
    }
}
