package com.elitemaster.booster;

import android.app.Activity;
import android.content.Intent;
import android.media.projection.MediaProjectionManager;
import android.os.Bundle;
import android.widget.Toast;

/** Invisible activity that shows Android's screen-capture consent, then hands the result to a service. */
public class CaptureActivity extends Activity {
    public static final String EXTRA_MODE = "mode";
    public static final int MODE_SHOT = 0, MODE_REC_DEVICE = 1, MODE_REC_VOICE = 2;
    private static final int REQ = 7001;
    private int mode;

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        mode = getIntent().getIntExtra(EXTRA_MODE, MODE_SHOT);
        MediaProjectionManager m = (MediaProjectionManager) getSystemService(MEDIA_PROJECTION_SERVICE);
        startActivityForResult(m.createScreenCaptureIntent(), REQ);
    }

    @Override protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        if (req == REQ) {
            if (res == RESULT_OK && data != null) {
                Intent s = new Intent(this, mode == MODE_SHOT ? ShotService.class : RecordService.class);
                s.setAction(RecordService.ACTION_START);
                s.putExtra("resultCode", res);
                s.putExtra("resultData", data);
                s.putExtra("voice", mode == MODE_REC_VOICE);
                startForegroundService(s);
            } else {
                Toast.makeText(this, "Permission denied", Toast.LENGTH_SHORT).show();
            }
        }
        finish();
        overridePendingTransition(0, 0);
    }
}
