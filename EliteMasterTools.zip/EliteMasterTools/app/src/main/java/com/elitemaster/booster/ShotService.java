package com.elitemaster.booster;

import android.app.Activity;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.content.ContentValues;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.graphics.Bitmap;
import android.graphics.PixelFormat;
import android.hardware.display.DisplayManager;
import android.hardware.display.VirtualDisplay;
import android.media.Image;
import android.media.ImageReader;
import android.media.projection.MediaProjection;
import android.media.projection.MediaProjectionManager;
import android.net.Uri;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.provider.MediaStore;
import android.util.DisplayMetrics;
import android.view.WindowManager;
import android.widget.Toast;

import java.io.OutputStream;
import java.nio.ByteBuffer;

public class ShotService extends Service {
    private static final String CH = "elite_shot";
    private MediaProjection projection;
    private VirtualDisplay vd;
    private ImageReader reader;
    private final Handler h = new Handler(Looper.getMainLooper());
    private int tries = 0, w, hgt;

    @Override public int onStartCommand(Intent in, int flags, int id) {
        getSystemService(NotificationManager.class)
            .createNotificationChannel(new NotificationChannel(CH, "Screenshot", NotificationManager.IMPORTANCE_LOW));
        Notification n = new Notification.Builder(this, CH).setSmallIcon(android.R.drawable.ic_menu_camera)
            .setContentTitle("ELITE MASTER").setContentText("Taking screenshot").build();
        startForeground(2001, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION);
        Intent data = getData(in);
        if (data == null) { stopSelf(); return START_NOT_STICKY; }
        try {
            MediaProjectionManager m = (MediaProjectionManager) getSystemService(MEDIA_PROJECTION_SERVICE);
            projection = m.getMediaProjection(in.getIntExtra("resultCode", Activity.RESULT_CANCELED), data);
            projection.registerCallback(new MediaProjection.Callback() {
                @Override public void onStop() { cleanup(); }
            }, h);
            DisplayMetrics dm = new DisplayMetrics();
            ((WindowManager) getSystemService(WINDOW_SERVICE)).getDefaultDisplay().getRealMetrics(dm);
            w = dm.widthPixels; hgt = dm.heightPixels;
            reader = ImageReader.newInstance(w, hgt, PixelFormat.RGBA_8888, 2);
            vd = projection.createVirtualDisplay("EliteShot", w, hgt, dm.densityDpi,
                DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, reader.getSurface(), null, null);
            h.postDelayed(this::grab, 700);   // let the permission dialog fade out first
        } catch (Exception e) {
            android.util.Log.e("EliteShot", "start failed", e);
            cleanup();
        }
        return START_NOT_STICKY;
    }

    private void grab() {
        if (reader == null) return;
        Image img = null;
        try {
            img = reader.acquireLatestImage();
            if (img == null) {
                if (++tries < 8) { h.postDelayed(this::grab, 300); return; }
                throw new IllegalStateException("no frame");
            }
            Image.Plane p = img.getPlanes()[0];
            ByteBuffer buf = p.getBuffer();
            int pad = p.getRowStride() - p.getPixelStride() * w;
            Bitmap full = Bitmap.createBitmap(w + pad / p.getPixelStride(), hgt, Bitmap.Config.ARGB_8888);
            full.copyPixelsFromBuffer(buf);
            Bitmap bmp = Bitmap.createBitmap(full, 0, 0, w, hgt);
            save(bmp);
            Toast.makeText(this, "Screenshot saved to Pictures/ELITE MASTER", Toast.LENGTH_SHORT).show();
        } catch (Exception e) {
            android.util.Log.e("EliteShot", "grab failed", e);
            Toast.makeText(this, "Screenshot failed", Toast.LENGTH_SHORT).show();
        } finally {
            if (img != null) img.close();
            cleanup();
        }
    }

    private void save(Bitmap bmp) throws Exception {
        ContentValues v = new ContentValues();
        v.put(MediaStore.Images.Media.DISPLAY_NAME, "ELITE_MASTER_" + System.currentTimeMillis() + ".png");
        v.put(MediaStore.Images.Media.MIME_TYPE, "image/png");
        v.put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/ELITE MASTER");
        v.put(MediaStore.Images.Media.IS_PENDING, 1);
        Uri u = getContentResolver().insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, v);
        if (u == null) throw new IllegalStateException("insert failed");
        try (OutputStream o = getContentResolver().openOutputStream(u)) {
            if (o == null || !bmp.compress(Bitmap.CompressFormat.PNG, 100, o)) throw new IllegalStateException("compress failed");
        }
        ContentValues d = new ContentValues();
        d.put(MediaStore.Images.Media.IS_PENDING, 0);
        getContentResolver().update(u, d, null, null);
    }

    private void cleanup() {
        h.removeCallbacksAndMessages(null);
        if (vd != null) { vd.release(); vd = null; }
        if (reader != null) { reader.close(); reader = null; }
        if (projection != null) { try { projection.stop(); } catch (Exception ignored) {} projection = null; }
        stopForeground(true);
        stopSelf();
    }

    @Override public void onDestroy() { cleanup(); super.onDestroy(); }
    @SuppressWarnings("deprecation")
    private static Intent getData(Intent i) {
        if (i == null) return null;
        return android.os.Build.VERSION.SDK_INT >= 33 ? i.getParcelableExtra("resultData", Intent.class) : (Intent) i.getParcelableExtra("resultData");
    }

    @Override public IBinder onBind(Intent i) { return null; }
}
