ELITE MASTER TOOLS - how to get the APK (phone only, ~5 minutes)
1. Make a free account at github.com and create a new repository (name: EliteMasterTools).
2. Upload ALL files from this zip, keeping the folders (on the phone: "Add file > Upload files"; the ".github" folder must be included).
3. Open the "Actions" tab > "Build APK" > wait for the green tick > open the run > download "EliteMaster-Tools-APK" > unzip > install app-debug.apk.
If the build shows a red cross, copy the error text and send it to me.
